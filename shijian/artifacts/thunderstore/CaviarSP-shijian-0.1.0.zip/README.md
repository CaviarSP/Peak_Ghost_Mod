# shijian

Become a ghost to visit your below friends:

- Stand near an **unlit campfire**
- Press **key `G`** to enter ghost mode

Revive from a ghost:

- Press **key `G`** again  
- Or wait until **all characters pass out**

---

### 🔧 Change toggle key via config

- You can change the default hotkey (`G`) in the config file
- Install and configure this plugin via **GaleModManager**  
  *(available on [Thunderstore](https://thunderstore.io/))*
